part of 'resources.dart';

class Vectors {
  Vectors._();

  static const String facebook = 'assets/vectors/facebook.svg';
  static const String google = 'assets/vectors/google.svg';
}
