class AppRoutes {
  const AppRoutes._();

  static const String login = 'login';
  static const String register = 'register';
}
